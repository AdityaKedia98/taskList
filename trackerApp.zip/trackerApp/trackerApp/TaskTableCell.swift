//
//  TaskTableCell.swift
//  trackerApp
//
//  Created by Aditya Kedia on 10/12/25.
//

import UIKit

class TaskTableCell: UITableViewCell {

    @IBOutlet var status: UILabel!
    @IBOutlet var subTitle: UILabel!
    @IBOutlet var heading: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        self.contentView.layer.borderWidth = 1.0
        self.contentView.layer.borderColor = UIColor.black.cgColor
        self.contentView.layer.cornerRadius = 8.0
    }
    
    func setValue(task: Task) {
        heading.text = task.title
        subTitle.text = task.description
        
        if task.status {
            status.text = String(format: "%@%@", "status: ","Completed")
        } else {
            status.text = String(format: "%@%@", "status: ","Pending")
        }
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }

}
