//
//  TaskDetailVC.swift
//  trackerApp
//
//  Created by Aditya Kedia on 10/12/25.
//

import UIKit

class TaskDetailVC: UIViewController {

    @IBOutlet var btnMakr: UIButton!
    @IBOutlet var lblStatus: UILabel!
    @IBOutlet var lblDesc: UILabel!
    @IBOutlet var lblTitle: UILabel!
    
    var task: Task!
    var taskIndex: Int!

    private let tasksKey = "tasks"
    private var statusBarButton: UIBarButtonItem!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupNavBarButton()
        configureView()
        btnMakr.layer.borderWidth = 1
        btnMakr.layer.borderColor = UIColor.black.cgColor
        btnMakr.layer.cornerRadius = 12
        self.title = "Detail Screen"
    }
    
    private func configureView() {
        lblTitle.text = task.title
        lblDesc.text = task.description
        updateStatusLabel()
        updateBarButtonImage()
    }
    
    private func updateStatusLabel() {
        if task.status {
            lblStatus.text = String(format: "%@%@", "status: ","Completed")
            btnMakr.setTitle(String(format: "%@%@", "Mark as: ","Pending"), for: .normal)
        } else {
            lblStatus.text = String(format: "%@%@", "status: ","Pending")
            btnMakr.setTitle(String(format: "%@%@", "Mark as: ","Completed"), for: .normal)
        }
    }
    
    private func setupNavBarButton() {
        // choose SF Symbols: checkmark.circle.fill for completed, circle for pending
        statusBarButton = UIBarButtonItem(image: nil, style: .plain, target: self, action: nil)
        statusBarButton.tintColor = .systemBlue
        navigationItem.rightBarButtonItem = statusBarButton
        updateBarButtonImage()
    }
    
    private func updateBarButtonImage() {
        let imageName = task.status ? "checkmark.circle.fill" : "circle"
        // always use system images (requires iOS 13+)
        statusBarButton.image = UIImage(systemName: imageName)
    }
    
    @IBAction func pressMarkAsCompleteOrPending(_ sender: Any) {
        // toggle local model
        
        
        
        task.status.toggle()
       
        // update UI
        updateStatusLabel()
        updateBarButtonImage()
        // persist change
        var tasks = loadTasks()
        if let index = taskIndex, index >= 0, index < tasks.count {
            tasks[index].status = task.status
            saveTasks(tasks)
        } else {
            // fallback: attempt to find by title/description (if index missing)
            if let foundIndex = tasks.firstIndex(where: { $0.title == task.title && $0.description == task.description }) {
                tasks[foundIndex].status = task.status
                saveTasks(tasks)
            }
        }
    }
    
    // MARK: - Persistence helpers
    private func saveTasks(_ tasks: [Task]) {
        if let data = try? JSONEncoder().encode(tasks) {
            UserDefaults.standard.set(data, forKey: tasksKey)
        }
    }
    
    private func loadTasks() -> [Task] {
        if let data = UserDefaults.standard.data(forKey: tasksKey),
           let saved = try? JSONDecoder().decode([Task].self, from: data) {
            return saved
        } else {
            return []
        }
    }
}
