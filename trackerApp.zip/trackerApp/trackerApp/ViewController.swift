//
//  ViewController.swift
//  trackerApp
//
//  Created by Aditya Kedia on 10/12/25.
//

import UIKit

struct Task: Codable {
    var title: String
    var description: String
    var status: Bool
}

class ViewController: UIViewController {

    @IBOutlet var taskTableView: UITableView!
    
    private let tasksKey = "tasks"
    private var allTasks: [Task] = []          // full source of truth
    private var filteredTasks: [Task] = []     // dataSource for table

    // filter state cycles All -> Completed -> Pending -> All
    private enum FilterState {
        case all, completed, pending
        
        mutating func toggle() {
            switch self {
            case .all: self = .completed
            case .completed: self = .pending
            case .pending: self = .all
            }
        }
        
        var title: String {
            switch self {
            case .all: return "All"
            case .completed: return "Completed"
            case .pending: return "Pending"
            }
        }
    }
    private var filterState: FilterState = .all {
        didSet {
            applyFilter()
            updateFilterBarButton()
        }
    }

    private var filterBarButton: UIBarButtonItem!

    override func viewDidLoad() {
        super.viewDidLoad()
        taskTableView.delegate = self
        taskTableView.dataSource = self
        self.title = "Home Screen"
        setupFilterButton()
        allTasks = loadTasks()
        applyFilter()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        // reload tasks (in case status changed in detail VC) and reapply filter
        allTasks = loadTasks()
        applyFilter()
    }
    
    // MARK: - Filter Button
    private func setupFilterButton() {
        filterBarButton = UIBarButtonItem(title: filterState.title, style: .plain, target: self, action: #selector(didTapFilterButton))
        filterBarButton.tintColor = .systemBlue
        navigationItem.rightBarButtonItem = filterBarButton
    }
    
    private func updateFilterBarButton() {
        filterBarButton.title = filterState.title
        // keep blue tint
        filterBarButton.tintColor = .systemBlue
    }
    
    @objc private func didTapFilterButton() {
        filterState.toggle()
        // applyFilter() and UI update happen in didSet
    }
    
    // MARK: - Filtering
    private func applyFilter() {
        switch filterState {
        case .all:
            filteredTasks = allTasks
        case .completed:
            filteredTasks = allTasks.filter { $0.status == true }
        case .pending:
            filteredTasks = allTasks.filter { $0.status == false }
        }
        taskTableView.reloadData()
    }

    // MARK: - Persistence helpers
    private func saveTasks(_ tasks: [Task]) {
        if let data = try? JSONEncoder().encode(tasks) {
            UserDefaults.standard.set(data, forKey: tasksKey)
        }
    }
    
    private func loadTasks() -> [Task] {
        if let data = UserDefaults.standard.data(forKey: tasksKey),
           let saved = try? JSONDecoder().decode([Task].self, from: data) {
            return saved
        } else {
            // sample tasks (remove if you seed elsewhere)
            let samples = [
                Task(title: "Buy groceries", description: "Milk, Eggs, Bread", status: false),
                Task(title: "Call mom", description: "Discuss weekend plan", status: true),
                Task(title: "Read book", description: "Finish Chapter 4", status: false)
            ]
            saveTasks(samples)
            return samples
        }
    }
}

extension ViewController: UITableViewDelegate{
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "TaskDetailVC") as! TaskDetailVC
        // pass the task and its index in the full array (so detail can persist changes)
        // find index of tapped item in allTasks (not filteredTasks) by matching title/description
        let tapped = filteredTasks[indexPath.row]
        if let fullIndex = allTasks.firstIndex(where: { $0.title == tapped.title && $0.description == tapped.description }) {
            vc.task = tapped
            vc.taskIndex = fullIndex
        } else {
            vc.task = tapped
            vc.taskIndex = indexPath.row
        }
        self.navigationController?.pushViewController(vc, animated: true)
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
}
extension ViewController: UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        filteredTasks.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cell = tableView.dequeueReusableCell(withIdentifier: "TaskTableCell") as! TaskTableCell
        cell.setValue(task: filteredTasks[indexPath.row])
        return cell
    }
}
